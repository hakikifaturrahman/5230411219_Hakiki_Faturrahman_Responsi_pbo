import tkinter as tk
from tkinter import ttk, messagebox
import mysql.connector
from datetime import date

class DatabaseConnection:
    """Kelas untuk menangani koneksi database MySQL."""
    def __init__(self):
        self.connection = mysql.connector.connect(
            host="localhost",
            user="root",  # Ganti dengan username database Anda
            password="",  # Ganti dengan password database Anda
            database="retail_tokoh"
        )
        self.cursor = self.connection.cursor()

    def execute_query(self, query, params=None):
        self.cursor.execute(query, params or ())
        self.connection.commit()

    def fetch_data(self, query, params=None):
        self.cursor.execute(query, params or ())
        return self.cursor.fetchall()

    def close(self):
        self.cursor.close()
        self.connection.close()

class ProductManagement:
    def __init__(self, master):
        self.master = master

        # Inisialisasi koneksi database
        self.db = DatabaseConnection()

        # Styling
        style = ttk.Style()
        style.configure("TLabel", font=("Arial", 12), padding=5)
        style.configure("TEntry", font=("Arial", 12))

        # Frame utama
        self.frame = ttk.Frame(self.master, padding=20)
        self.frame.pack(fill="both", expand=True)

        # Form input produk
        ttk.Label(self.frame, text="Nama Produk:").grid(row=0, column=0, sticky="w")
        self.name_entry = ttk.Entry(self.frame, width=30)
        self.name_entry.grid(row=0, column=1, pady=5)

        ttk.Label(self.frame, text="Harga Produk:").grid(row=1, column=0, sticky="w")
        self.price_entry = ttk.Entry(self.frame, width=30)
        self.price_entry.grid(row=1, column=1, pady=5)

        ttk.Label(self.frame, text="Stok Produk:").grid(row=2, column=0, sticky="w")
        self.stock_entry = ttk.Entry(self.frame, width=30)
        self.stock_entry.grid(row=2, column=1, pady=5)

        # Tombol CRUD
        button_frame = ttk.Frame(self.frame)
        button_frame.grid(row=3, column=0, columnspan=2, pady=10)

        self.add_button = tk.Button(button_frame, text="Tambah Produk", bg="blue", fg="white", font=("Arial", 12), command=self.add_product)
        self.add_button.pack(side="left", padx=5)

        self.update_button = tk.Button(button_frame, text="Ubah Produk", bg="brown", fg="white", font=("Arial", 12), command=self.update_product)
        self.update_button.pack(side="left", padx=5)

        self.delete_button = tk.Button(button_frame, text="Hapus Produk", bg="red", fg="white", font=("Arial", 12), command=self.delete_product)
        self.delete_button.pack(side="left", padx=5)
        

        # Tabel produk
        self.product_table = ttk.Treeview(self.master, columns=("ID", "Nama Produk", "Harga", "Stok"), show="headings")
        self.product_table.heading("ID", text="ID")
        self.product_table.heading("Nama Produk", text="Nama Produk")
        self.product_table.heading("Harga", text="Harga")
        self.product_table.heading("Stok", text="Stok")

        self.product_table.column("ID", width=50, anchor="center")
        self.product_table.column("Nama Produk", width=200, anchor="w")
        self.product_table.column("Harga", width=100, anchor="center")
        self.product_table.column("Stok", width=80, anchor="center")

        self.product_table.pack(pady=10, fill="both", expand=True)

        self.product_table.bind("<ButtonRelease-1>", self.fill_form)

        self.load_products()

    def add_product(self):
        """Tambah produk ke database."""
        name = self.name_entry.get()
        price = self.price_entry.get()
        stock = self.stock_entry.get()

        # Validasi input: Pastikan semua kolom terisi
        if not name or not price or not stock:
            messagebox.showwarning("Peringatan", "Semua kolom harus diisi!")
            return

        try:
            # Konversi harga dan stok ke tipe data yang sesuai
            price = float(price)
            stock = int(stock)
            
            # Periksa apakah harga dan stok bernilai positif
            if price <= 0 or stock < 0:
                messagebox.showwarning("Peringatan", "Harga harus lebih dari 0 dan stok tidak boleh negatif!")
                return
            
            # Eksekusi query untuk menambahkan produk ke database
            self.db.execute_query("INSERT INTO products (name, price, stock) VALUES (%s, %s, %s)", (name, price, stock))
            
            # Berikan feedback kepada user bahwa produk berhasil ditambahkan
            messagebox.showinfo("Sukses", "Produk berhasil ditambahkan!")
            
            # Refresh tabel produk setelah penambahan
            self.load_products()  
            
            # Reset input field setelah berhasil menambah produk
            self.name_entry.delete(0, 'end')
            self.price_entry.delete(0, 'end')
            self.stock_entry.delete(0, 'end')
            
        except ValueError:
            # Tangani error jika harga dan stok bukan angka
            messagebox.showerror("Error", "Harga dan stok harus berupa angka!")
        except Exception as e:
            # Tangani exception umum lainnya (misalnya kesalahan database)
            messagebox.showerror("Error", f"Terjadi kesalahan: {str(e)}")


    def update_product(self):
        """Mengubah produk di database."""
        selected_item = self.product_table.focus()
        if not selected_item:
            messagebox.showwarning("Peringatan", "Pilih produk yang ingin diubah!")
            return

        product_id = self.product_table.item(selected_item, "values")[0]
        name = self.name_entry.get()
        price = self.price_entry.get()
        stock = self.stock_entry.get()

        if not name or not price or not stock:
            messagebox.showwarning("Peringatan", "Semua kolom harus diisi!")
            return

        try:
            price = float(price)
            stock = int(stock)
            self.db.execute_query(
                "UPDATE products SET name = %s, price = %s, stock = %s WHERE id = %s", 
                (name, price, stock, product_id)
            )
            messagebox.showinfo("Sukses", "Produk berhasil diubah!")
            self.load_products()
        except ValueError:
            messagebox.showerror("Error", "Harga dan stok harus berupa angka!")

    def delete_product(self):
        """Menghapus produk dari database dan semua transaksi terkait."""
        selected_item = self.product_table.focus()
        if not selected_item:
            messagebox.showwarning("Peringatan", "Pilih produk yang ingin dihapus!")
            return

        product_id = self.product_table.item(selected_item, "values")[0]

        # Konfirmasi penghapusan
        confirm = messagebox.askyesno(
            "Konfirmasi Hapus",
            f"Apakah Anda yakin ingin menghapus produk ini beserta semua transaksi terkait?"
        )
        if not confirm:
            return

        try:
            # Hapus transaksi terkait produk
            self.db.execute_query("DELETE FROM transactions WHERE product_id = %s", (product_id,))
            
            # Hapus produk dari tabel produk
            self.db.execute_query("DELETE FROM products WHERE id = %s", (product_id,))
            
            # Tampilkan pesan sukses
            messagebox.showinfo("Sukses", "Produk dan semua transaksi terkait berhasil dihapus!")
            self.load_products()  # Perbarui tabel produk
        except Exception as e:
            messagebox.showerror("Error", f"Terjadi kesalahan: {e}")



    def load_products(self):
        """Memuat data produk dari database."""
        for item in self.product_table.get_children():
            self.product_table.delete(item)

        products = self.db.fetch_data("SELECT * FROM products")
        for product in products:
            self.product_table.insert("", "end", values=product)

    def fill_form(self, event):
        """Mengisi form dengan data dari tabel."""
        selected_item = self.product_table.focus()
        if not selected_item:
            return

        values = self.product_table.item(selected_item, "values")
        self.name_entry.delete(0, tk.END)
        self.name_entry.insert(0, values[1])
        self.price_entry.delete(0, tk.END)
        self.price_entry.insert(0, values[2])
        self.stock_entry.delete(0, tk.END)
        self.stock_entry.insert(0, values[3])

class TransactionManagement:
    def __init__(self, master):
        self.master = master

        # Inisialisasi koneksi database
        self.db = DatabaseConnection()

        # Frame utama
        self.frame = ttk.Frame(self.master, padding=20)
        self.frame.pack(fill="both", expand=True)

        # Form input transaksi
        ttk.Label(self.frame, text="Produk:").grid(row=0, column=0, sticky="w")
        self.product_combobox = ttk.Combobox(self.frame, state="readonly", width=30)
        self.product_combobox.grid(row=0, column=1, pady=5)

        ttk.Label(self.frame, text="Jumlah:").grid(row=1, column=0, sticky="w")
        self.quantity_entry = ttk.Entry(self.frame, width=30)
        self.quantity_entry.grid(row=1, column=1, pady=5)

        # Tombol CRUD
        button_frame = ttk.Frame(self.frame)
        button_frame.grid(row=2, column=0, columnspan=2, pady=10)

        self.add_button = tk.Button(button_frame, text="Tambah Transaksi", bg="orange", fg="white", font=("Arial", 12), command=self.add_transaction)
        self.add_button.pack(side="left", padx=5)

        self.delete_button = tk.Button(button_frame, text="Hapus Transaksi", bg="red", fg="white", font=("Arial", 12), command=self.delete_transaction)
        self.delete_button.pack(side="left", padx=5)

        # Tabel transaksi
        self.transaction_table = ttk.Treeview(self.master, columns=("ID", "Produk", "Jumlah", "Total Harga", "Tanggal"), show="headings")
        self.transaction_table.heading("ID", text="ID")
        self.transaction_table.heading("Produk", text="Produk")
        self.transaction_table.heading("Jumlah", text="Jumlah")
        self.transaction_table.heading("Total Harga", text="Total Harga")
        self.transaction_table.heading("Tanggal", text="Tanggal")

        self.transaction_table.column("ID", width=50, anchor="center")
        self.transaction_table.column("Produk", width=200, anchor="w")
        self.transaction_table.column("Jumlah", width=100, anchor="center")
        self.transaction_table.column("Total Harga", width=120, anchor="center")
        self.transaction_table.column("Tanggal", width=150, anchor="center")

        self.transaction_table.pack(pady=10, fill="both", expand=True)

        # Load data
        self.products_map = {}
        self.load_products()
        self.load_transactions()

    def load_products(self):
        """Memuat daftar produk untuk combobox."""
        products = self.db.fetch_data("SELECT id, name FROM products")
        self.products_map = {product[1]: product[0] for product in products}  # Peta nama produk ke ID
        self.product_combobox["values"] = list(self.products_map.keys())  # Hanya nama produk yang ditampilkan

    def add_transaction(self):
        """Tambah transaksi ke database."""
        selected_product = self.product_combobox.get()
        if not selected_product:
            messagebox.showwarning("Peringatan", "Pilih produk terlebih dahulu!")
            return

        product_id = self.products_map.get(selected_product)
        if not product_id:
            messagebox.showerror("Error", "Produk tidak valid!")
            return

        quantity = self.quantity_entry.get()
        if not quantity.isdigit():
            messagebox.showerror("Error", "Jumlah harus berupa angka!")
            return

        quantity = int(quantity)
        product = self.db.fetch_data("SELECT price, stock FROM products WHERE id = %s", (product_id,))
        if not product:
            messagebox.showerror("Error", "Produk tidak ditemukan!")
            return

        price, stock = product[0]
        if quantity > stock:
            messagebox.showerror("Error", "Stok produk tidak mencukupi!")
            return

        total_price = price * quantity
        transaction_date = date.today()

        self.db.execute_query(
            "INSERT INTO transactions (product_id, quantity, total_price, transaction_date) VALUES (%s, %s, %s, %s)",
            (product_id, quantity, total_price, transaction_date)
        )
        self.db.execute_query(
            "UPDATE products SET stock = stock - %s WHERE id = %s",
            (quantity, product_id)
        )
        messagebox.showinfo("Sukses", "Transaksi berhasil ditambahkan!")
        self.load_transactions()
        self.load_products()  # Perbarui stok di combobox

    def delete_transaction(self):
        """Menghapus transaksi dari database."""
        selected_item = self.transaction_table.focus()
        if not selected_item:
            messagebox.showwarning("Peringatan", "Pilih transaksi yang ingin dihapus!")
            return

        transaction_id = self.transaction_table.item(selected_item, "values")[0]
        quantity = self.transaction_table.item(selected_item, "values")[2]
        product_name = self.transaction_table.item(selected_item, "values")[1]
        product_id = self.products_map.get(product_name)

        self.db.execute_query("DELETE FROM transactions WHERE id = %s", (transaction_id,))
        self.db.execute_query(
            "UPDATE products SET stock = stock + %s WHERE id = %s",
            (quantity, product_id)
        )
        messagebox.showinfo("Sukses", "Transaksi berhasil dihapus!")
        self.load_transactions()
        self.load_products()

    def load_transactions(self):
        """Memuat data transaksi dari database."""
        for item in self.transaction_table.get_children():
            self.transaction_table.delete(item)

        transactions = self.db.fetch_data("""
            SELECT t.id, p.name, t.quantity, t.total_price, t.transaction_date
            FROM transactions t
            JOIN products p ON t.product_id = p.id
        """)
        for transaction in transactions:
            self.transaction_table.insert("", "end", values=transaction)


def main():
    root = tk.Tk()
    root.title("Manajemen Produk dan Transaksi")
    root.geometry("800x600")

    # Pilih frame manajemen produk atau transaksi
    notebook = ttk.Notebook(root)
    product_frame = ttk.Frame(notebook, padding=10)
    transaction_frame = ttk.Frame(notebook, padding=10)

    notebook.add(product_frame, text="Produk")
    notebook.add(transaction_frame, text="Transaksi")
    notebook.pack(expand=True, fill="both")

    ProductManagement(product_frame)
    TransactionManagement(transaction_frame)

    root.mainloop()

if __name__ == "__main__":
    main()